Instruções:
1° Extraia o arquivo;
2° Crie a pasta Escape_From_The_area_52 no diretório abaixo:
	C:\Users\<Usuário do sistema>\AppData\Local\
3° Copie e cole o arquivo score.txt no diretório criado;
	C:\Users\<Usuário do sistema>\AppData\Local\Escape_From_The_area_52